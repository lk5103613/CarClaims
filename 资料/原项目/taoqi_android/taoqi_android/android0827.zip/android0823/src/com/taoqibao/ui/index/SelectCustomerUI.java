package com.taoqibao.ui.index;

import android.app.Activity;
import android.os.Bundle;

import com.taoqibao.ui.R;


public class SelectCustomerUI extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.select_customer);
	}

}
