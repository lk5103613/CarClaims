/** Automatically generated file. DO NOT MODIFY */
package com.example.jiemian_n;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}