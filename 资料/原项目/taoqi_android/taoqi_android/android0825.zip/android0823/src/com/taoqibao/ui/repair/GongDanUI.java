package com.taoqibao.ui.repair;

import com.taoqibao.ui.R;
import com.taoqibao.ui.R.layout;

import android.app.Activity;
import android.os.Bundle;

public class GongDanUI extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gongdan);
	}

}
