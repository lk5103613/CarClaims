package com.taoqibao.ui;

import android.app.Activity;
import android.os.Bundle;

public class SelectHuiYuanUI extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.select_huiyuan);
	}

}
