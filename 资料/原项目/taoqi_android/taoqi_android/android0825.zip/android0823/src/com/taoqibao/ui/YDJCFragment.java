package com.taoqibao.ui;

public class YDJCFragment extends BaseFagment {

}
