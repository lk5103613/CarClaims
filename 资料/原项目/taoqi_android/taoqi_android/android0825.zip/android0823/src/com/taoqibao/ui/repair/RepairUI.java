package com.taoqibao.ui.repair;

import android.app.Activity;
import android.os.Bundle;

import com.taoqibao.ui.R;

public class RepairUI extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.repair_step2);
	}

}
